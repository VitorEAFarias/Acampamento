﻿using System;
using Topshelf;

namespace ROServiceCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            HostFactory.Run(configure =>
            {
                configure.Service<MyService>(service =>
                {
                    service.ConstructUsing(s => new MyService());
                    service.WhenStarted(s => s.Start());
                    service.WhenStopped(s => s.Stop());
                });

                configure.RunAsLocalSystem();
                configure.SetServiceName("RO.ServiceCheck");
                configure.SetDisplayName("RO Service Status");
                configure.SetDescription("Verifica Serviço OS");
            });
        }
    }
}
