﻿using System;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ROServiceCheck
{
    public class MySQLConnection
    {
        protected MySqlConnection Con;
        protected MySqlCommand Cmd;
        protected MySqlDataReader Dr;

        LogEvent _log = new LogEvent();

        protected void OpenConnection()
        {
            try
            {
                string conMySql = "Server=10.0.3.41;Database=tarifador_srv;Uid=rocontrole;Pwd=Reis@2021;Pooling=True;SslMode=None;default command timeout=280";
                Con = new MySqlConnection(conMySql);
                Con.Open();
                _log.WriteEntry("Conexão realizada com sucesso : " + EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Erro ao realizar a conexão com MySql : " + ex.Message.ToString(), EventLogEntryType.Error);
                throw new Exception(ex.Message);
            }
        }
        protected void CloseConnection()
        {
            try
            {
                Con.Dispose();
                Con.Close();
            }
            catch (Exception ex)
            {

                _log.WriteEntry("Erro de Conexao: " + ex.Message.ToString(), EventLogEntryType.Error);
            }

        }
    }
}
