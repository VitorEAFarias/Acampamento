﻿using System;
using System.Diagnostics;
using System.Timers;
using System.ServiceProcess;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace ROServiceCheck
{
    public class MyService: MySQLConnection
    {
        LogEvent _log = new LogEvent();
        public void Start()
        {
            verificaStatus();
            var timer = new Timer();
            timer.Interval = 1800000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(checkTimer);
            timer.Enabled = true;
        }

        public void verificaStatus()
        {
            ServiceController[] services = ServiceController.GetServices();

            OpenConnection();           

            foreach (ServiceController service in services)
            {
                try
                {
                    if (service.ServiceName.Equals("Ro.Upload.Analisys"))
                    {
                        //var nomeServico = service.ServiceName.ToString();
                        var StatusServico = service.Status.ToString();
                        StatusObject objeto = new StatusObject();

                        if (StatusServico.Equals("Running"))
                        {                            
                            objeto.status = "Rodando";
                            objeto.serviceName = service.ServiceName;
                            _log.WriteEntry("Serviço rodando : " + service.ServiceName.ToString(), EventLogEntryType.Information);
                        }                            
                        else
                        {
                            objeto.status = "Parado";
                            objeto.serviceName = service.ServiceName;
                            _log.WriteEntry("Serviço parado : " + service.ServiceName.ToString(), EventLogEntryType.Information);
                        }

                        string Sql = "Update `tarifador_srv`.`servicestatus` SET";
                        Sql += " status=@v1,";
                        Sql += " timeServiceCheck=@v2";
                        Sql += " where `serviceName`='"+ service.ServiceName+"'";
                            
                        using (Cmd = new MySqlCommand(Sql, Con))
                        {
                            Cmd.CommandText = Sql;
                            Cmd.Parameters.AddWithValue("@v2", DateTime.Now);
                            Cmd.Parameters.AddWithValue("@v1", objeto.status);

                            Cmd.ExecuteNonQuery();
                        }                       
                    }                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void checkTimer(object sender, ElapsedEventArgs e)
        {
            verificaStatus();
        }
        public void Stop()
        {
            _log.WriteEntry("Serviço Parado: " + EventLogEntryType.Information);
        }
    }
}
