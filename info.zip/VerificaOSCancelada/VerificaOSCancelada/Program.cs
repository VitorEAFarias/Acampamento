﻿using System;
using Topshelf;

namespace VerificaOSCancelada
{
    class Program
    {
        static void Main(string[] args)
        {
            HostFactory.Run(configure =>
            {
                configure.Service<MyService>(service =>
                {
                    service.ConstructUsing(s => new MyService());
                    service.WhenStarted(s => s.Start());
                    service.WhenStopped(s => s.Stop());
                });
                
                configure.RunAsLocalSystem();
                configure.SetServiceName("RO.GerenciamentoDeOSCancelada");
                configure.SetDisplayName("Gerenciamento De OS Cancelada");
                configure.SetDescription("Gerenciamento de OS cancelada");
            });            
        }
    }
}
