﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.ModelosInformation;
using VerificaOSCancelada.DAL.InterfacesDAL;
using VerificaOSCancelada.BLL.BusinessFinallyBLL;

namespace VerificaOSCancelada.BLL.BusinessUploadBLL
{
    public class ListaCanceladasBLL : InterfacesBLL.ICanceladasBLL
    {
        private ICanceladasDAL _icanceladas;
        public ListaCanceladasBLL()
        {
            _icanceladas = FactoryCanceladas.inicializaCanceladas();
        }
        public List<OsCanceladasInformation> ListaOsCanceladas()
        {
            return _icanceladas.ListaOsCanceladas();
        }
    }
}
