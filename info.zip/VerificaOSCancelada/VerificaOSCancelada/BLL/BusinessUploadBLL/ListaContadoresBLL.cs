﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.ModelosInformation;
using VerificaOSCancelada.DAL.InterfacesDAL;
using VerificaOSCancelada.BLL.BusinessFinallyBLL;

namespace VerificaOSCancelada.BLL.BusinessUploadBLL
{
    public class ListaContadoresBLL : InterfacesBLL.IContadoresBLL
    {
        private IContadoresDAL _icontadores;
        public ListaContadoresBLL()
        {
            _icontadores = FactoryCanceladas.inicializaAuditoria();
        }
        public List<ContadorAuditoriaInformation> ContadoresAuditoria()
        {
            return _icontadores.ContadoresAuditoria();
        }
    }
}