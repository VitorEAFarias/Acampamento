﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.DAL;

namespace VerificaOSCancelada.BLL.BusinessFinallyBLL
{
    public class FactoryCanceladas
    {
        public static AuditoriaContadoresDAL inicializaAuditoria()
        {
            return new AuditoriaContadoresDAL();
        }

        public static OsCanceladasDAL inicializaCanceladas()
        {
            return new OsCanceladasDAL();
        }
    }
}
