﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.ModelosInformation;

namespace VerificaOSCancelada.BLL.BusinessFinallyBLL.BaseCanceladasBLL
{
    public interface IVerificaCanceladas
    {
        List<ContadorAuditoriaInformation> ListarContadores();
        List<OsCanceladasInformation> ListaCanceladas();
    }
}
