﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.DAL.InterfacesDAL;
using VerificaOSCancelada.BLL.BusinessFinallyBLL;

namespace VerificaOSCancelada.BLL.BusinessFinallyBLL
{
    public class ReabreOSCancelada //: BaseCanceladasBLL.IVerificaCanceladas
    {
        private IContadoresDAL _contadores;
        private ICanceladasDAL _canceladas;
        public ReabreOSCancelada()
        {
            _contadores = FactoryCanceladas.inicializaAuditoria();
            _canceladas = FactoryCanceladas.inicializaCanceladas();
        }

        public void verificaOs()
        {            
            
        }
    }
}
