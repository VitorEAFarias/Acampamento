﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerificaOSCancelada.DAL;
using VerificaOSCancelada.BLL.BusinessUploadBLL;

namespace VerificaOSCancelada.BLL
{
    public static class Factory
    {
        /// <summary>
        /// Factory Lista de OS's canceladas MySql
        /// </summary>
        /// <returns></returns>
        public static OsCanceladasDAL ListaOsCanceladasBLL()
        {
            return new OsCanceladasDAL();
        }

        //public static ListaCanceladasBLL ListaOsCanceladasBLL()
        //{
        //    return new ListaCanceladasBLL();
        //}

        /// <summary>
        /// Factory Lista contadores dos equipamentos MySql
        /// </summary>
        /// <returns></returns>
        public static AuditoriaContadoresDAL ListaContadoresBLL()
        {
            return new AuditoriaContadoresDAL();
        }
       
        //public static ListaContadoresBLL ListaContadoresBLL()
        //{
        //    return new ListaContadoresBLL();
        //}
    }
}
