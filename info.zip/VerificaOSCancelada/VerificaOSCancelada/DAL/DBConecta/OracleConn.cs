﻿using System;
using Oracle.ManagedDataAccess.Client;
using VerificaOSCancelada.Properties;
using System.Diagnostics;

namespace VerificaOSCancelada.DAL.DBConecta
{
    public class OracleConn
    {
        protected OracleConnection Con;
        protected OracleCommand Cmd;
        protected OracleDataReader Dr;

        LogEvent _log = new LogEvent();

        public void OpenConnection()
        {
            try
            {
                string strConOra = Properties.Resources.StringOracle;
                Con = new OracleConnection(strConOra);
                Con.Open();
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Erro de Conexao Oracle : " + ex.Message.ToString(), EventLogEntryType.Error);
                throw new Exception(ex.Message);
            }
        }

        public void CloseConnection()
        {
            try
            {
                Con.Close();
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Erro ao fechar a conexão com Oracle : " + ex.Message.ToString(), EventLogEntryType.Error);

                throw new Exception(ex.Message);
            }
        }
    }
}
