﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using VerificaOSCancelada.Properties;

namespace VerificaOSCancelada.DAL.DBConecta
{
    public class MySQLConn
    {
        protected MySqlConnection Con;
        protected MySqlCommand Cmd;
        protected MySqlDataReader Dr;

        LogEvent _log = new LogEvent();

        protected void OpenConnection()
        {
            try
            {
                string conMySql = Properties.Resources.StringMySQL;
                Con = new MySqlConnection(conMySql);
                Con.Open();
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Erro ao realizar a conexão com MySql : " + ex.Message.ToString(), EventLogEntryType.Error);
                throw new Exception(ex.Message);
            }
        }
        protected void CloseConnection()
        {
            try
            {
                Con.Dispose();
                Con.Close();
            }
            catch (Exception ex)
            {

                _log.WriteEntry("Erro de Conexao: " + ex.Message.ToString(), EventLogEntryType.Error);
            }

        }
    }
}
