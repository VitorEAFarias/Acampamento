﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using VerificaOSCancelada.ModelosInformation;
using VerificaOSCancelada.DAL.DBConecta;
using VerificaOSCancelada.Properties;

namespace VerificaOSCancelada.DAL
{
    public class AuditoriaContadoresDAL: MySQLConn, InterfacesDAL.IContadoresDAL
    {
        LogEvent _log = new LogEvent();
        public List<ContadorAuditoriaInformation> ContadoresAuditoria()
        {
            var contadores = new List<ContadorAuditoriaInformation>();

            try
            {
                OpenConnection();

                string Str = "SELECT audeqp.data_atualizacao, audcli.id AS idAuditoriaCliente, cli.id AS idCliente, cli.razao as razao, eqp.id AS idEquipamento,";
                Str += " eqp.nr_serie_analisys as nrAnalisys, audeqp.valor as valor, audeqp.id_oid as oid, oids.numerador_analisys";
                Str += " FROM auditoria_equipamentos audeqp";
                Str += " JOIN equipamentos eqp ON eqp.id = audeqp.id_equipamento";
                Str += " JOIN oids ON oids.id = audeqp.id_oid";
                Str += " JOIN auditoria_clientes audcli ON audcli.id = audeqp.id_auditoria_cliente";
                Str += " JOIN clientes cli ON cli.id = audcli.id_cliente";
                Str += " WHERE eqp.ativo = 'SIM' AND audeqp.data_atualizacao BETWEEN DATE_ADD(NOW(), INTERVAL -1 DAY) AND NOW()";

                Cmd = new MySqlCommand(Str, Con);

                Dr = Cmd.ExecuteReader();

                while (Dr.Read())
                {
                    var contadoresEncontrados = new ContadorAuditoriaInformation();

                    contadoresEncontrados.idAuditoriaCliente = Convert.ToString(Dr["idAuditoriaCliente"]);
                    contadoresEncontrados.idCliente = Convert.ToString(Dr["idCliente"]);
                    contadoresEncontrados.razao = Convert.ToString(Dr["razao"]);
                    contadoresEncontrados.idEquipamento = Convert.ToString(Dr["idEquipamento"]);
                    contadoresEncontrados.nr_serie_analisys = Convert.ToString(Dr["nrAnalisys"]);
                    contadoresEncontrados.contador = Convert.ToInt64(Dr["valor"]);
                    contadoresEncontrados.idOid = Convert.ToString(Dr["oid"]);
                    contadoresEncontrados.numerador_analisys = Convert.ToString(Dr["numerador_analisys"]);
                    contadoresEncontrados.data_atualizacao = Convert.ToDateTime(Dr["data_atualizacao"]);

                    contadores.Add(contadoresEncontrados);
                }

                return contadores;
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Algo deu errado, verifique o log" + ex.Message, EventLogEntryType.Error);
                throw new Exception(ex.Message);
            }
        }
    }
}
