﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using VerificaOSCancelada.ModelosInformation;
using VerificaOSCancelada.DAL.DBConecta;
using VerificaOSCancelada.Properties;

namespace VerificaOSCancelada.DAL
{
    public class OsCanceladasDAL: MySQLConn, InterfacesDAL.ICanceladasDAL
    {
        LogEvent _log = new LogEvent();
        public List<OsCanceladasInformation> ListaOsCanceladas()
        {
            var osEncontrada = new List<OsCanceladasInformation>();

            try
            {
                OpenConnection();

                string Str = "SELECT `id`,";
                Str += " `id_equipamento`,";
                Str += " `numero_serie`,";
                Str += " `novo_medidor`,";
                Str += " `numero_os`";

                Str += " FROM `tarifador_srv`.`os_canceladas`";
                Str += " where `ativo`= 1";

                Cmd = new MySqlCommand(Str, Con);

                Dr = Cmd.ExecuteReader();
                
                while(Dr.Read())
                {
                    var listaCanceladas = new OsCanceladasInformation();
                    listaCanceladas.id_equipamento = Convert.ToString(Dr["id_equipamento"]);
                    listaCanceladas.numero_os = Convert.ToInt32(Dr["numero_os"]);
                    listaCanceladas.numero_serie = Convert.ToString(Dr["numero_serie"]);
                    listaCanceladas.novo_medidor = Convert.ToDecimal(Dr["novo_medidor"]);

                    osEncontrada.Add(listaCanceladas);
                }

                return osEncontrada;
            }
            catch (Exception ex)
            {
                _log.WriteEntry("Erro de conexão" + ex.Message, EventLogEntryType.Error);
                throw new Exception(ex.Message);
            }
        }        
    }
}
