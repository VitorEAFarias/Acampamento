﻿using System;
using System.Diagnostics;
using System.Timers;
using VerificaOSCancelada.Properties;
using VerificaOSCancelada.BLL.BusinessUploadBLL;
using VerificaOSCancelada.BLL.BusinessFinallyBLL;

namespace VerificaOSCancelada
{
    public class MyService
    {
        LogEvent _log = new LogEvent();

        private BLL.BusinessUploadBLL.InterfacesBLL.ICanceladasBLL _icanceladas;
        private BLL.BusinessUploadBLL.InterfacesBLL.IContadoresBLL _icontadores;

        public MyService()
        {
            //_icanceladas = FactoryCanceladas.inicializaCanceladas();
            //_icontadores = FactoryCanceladas.inicializaAuditoria();
        }
        public void Start()
        {
            var timer = new Timer();
            timer.Interval = 3600000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(checkTimer);
            timer.Enabled = true;
        }
        private void checkTimer(object sender, ElapsedEventArgs e)
        {
            var HorarMin = TimeSpan.Parse("01:00");
            var HoraMax = TimeSpan.Parse("01:59");
            var HoraAtual = TimeSpan.Parse(DateTime.Now.ToShortTimeString());

            if (HoraAtual >= HorarMin && HoraAtual <= HoraMax)
            {
                _log.WriteEntry("Verificando OS's: " + HoraAtual, EventLogEntryType.Information);
                
            }
            else
            {
                _log.WriteEntry("Ainda não é hora!!!" + HoraAtual, EventLogEntryType.Information);
            }
        }
        public void Stop()
        {
            _log.WriteEntry("Serviço Parado: " + EventLogEntryType.Information);
        }
    }
}
