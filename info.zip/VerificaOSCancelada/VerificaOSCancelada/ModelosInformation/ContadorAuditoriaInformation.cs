﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VerificaOSCancelada.ModelosInformation
{
    public class ContadorAuditoriaInformation
    {
        public string idAuditoriaCliente { get; set; }
        public string idCliente { get; set; }
        public string razao { get; set; }
        public string idEquipamento { get; set; }
        public string nr_serie_analisys { get; set; }
        public long contador { get; set; }
        public string idOid { get; set; }
        public string numerador_analisys{ get; set; }
        public DateTime data_atualizacao { get; set; }
    }
}
