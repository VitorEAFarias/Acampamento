﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VerificaOSCancelada.ModelosInformation
{
    public class OsCanceladasInformation
    {
        public string id_equipamento { get; set; }
        public string numero_serie { get; set; }
        public decimal novo_medidor { get; set; }
        public int numero_os { get; set; }
        public int ativo { get; set; }
    }
}
